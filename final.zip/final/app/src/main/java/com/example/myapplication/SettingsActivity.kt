package com.example.myapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.google.firebase.auth.EmailAuthProvider
import com.google.firebase.auth.FirebaseAuth
import kotlinx.android.synthetic.main.activity_settings.*

class SettingsActivity : AppCompatActivity() {
    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        auth = FirebaseAuth.getInstance()

        btn_change_password.setOnClickListener {
            changePassword()
        }

        logout_btn.setOnClickListener {
            FirebaseAuth.getInstance().signOut()
            val intent = Intent(this@SettingsActivity, MainActivity::class.java)
            startActivity(intent)
            finish()
        }
    }
        private fun changePassword() {
        if(et_current_password.text.toString().isNotEmpty() && et_new_password.text.toString().isNotEmpty() && et_confirm_password.text.toString().isNotEmpty()) {
            if (et_new_password.text.toString().equals(et_confirm_password.text.toString())){
                val user = auth.currentUser
                if (user != null && user.email != null){
                    val credential = EmailAuthProvider
                        .getCredential(user.email!!, et_current_password.text.toString())

                    user?.reauthenticate(credential)
                        ?.addOnCompleteListener {
                            if (it.isSuccessful){
                                Toast.makeText(this, "success", Toast.LENGTH_LONG).show()

                                user?.updatePassword(et_new_password.text.toString())
                                    ?.addOnCompleteListener { task ->
                                        if (task.isSuccessful) {
                                            Toast.makeText(this, "password changed successfully", Toast.LENGTH_LONG).show()
                                            auth.signOut()
                                            startActivity(Intent(this@SettingsActivity,MainActivity::class.java))
                                            finish()
                                        }
                                    }
                            }else{
                                Toast.makeText(this, "re-auth failed", Toast.LENGTH_LONG).show()
                            }
                        }
                }else {
                    startActivity(Intent(this@SettingsActivity,Sign_Up::class.java))
                    finish()
                }
            }else{
                Toast.makeText(this, "missmatch", Toast.LENGTH_LONG).show()
            }
        }
        else{
            Toast.makeText(this, "fill all the fields", Toast.LENGTH_LONG).show()
        }
    }


}

