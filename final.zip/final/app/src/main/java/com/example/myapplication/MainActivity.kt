package com.example.myapplication

import android.content.DialogInterface
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.TextUtils
import android.util.Log
import android.util.Patterns
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.google.firebase.auth.FirebaseAuth
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_sign__up.*
import java.util.regex.Pattern

class MainActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        auth = FirebaseAuth.getInstance()


        signup_link_btn.setOnClickListener{
            startActivity(Intent(this@MainActivity, Sign_Up::class.java))
        }

        login_btn.setOnClickListener {
            letUser()
        }
        forgot_password_view.setOnClickListener {
            val bulider = AlertDialog.Builder(this)
            bulider.setTitle("Email")

            val dialog = layoutInflater.inflate(R.layout.forgot_pass_dialog, null)
            val username = dialog.findViewById<EditText>(R.id.et_usr)
            bulider.setView(dialog)
            bulider.setPositiveButton("Reset", DialogInterface.OnClickListener{_ , _ ->
                forgotpassword(username)
            })
            bulider.show()

        }

    }

    private fun forgotpassword(username: EditText) {
        if (username.text.toString().isEmpty()){
            username.error = "enter email"
            return
        }
        if(!Patterns.EMAIL_ADDRESS.matcher(username.text.toString()).matches()){
            return
        }
        auth.sendPasswordResetEmail(username.text.toString())
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    Toast.makeText(this, "check your email", Toast.LENGTH_LONG).show()
                }
            }


    }

    private fun letUser() {
        val email = email_login.text.toString()
        val password = password_login.text.toString()

        when {
            TextUtils.isEmpty(email) -> Toast.makeText(this, "enter email", Toast.LENGTH_LONG).show()
            TextUtils.isEmpty(password) -> Toast.makeText(this, "enter password", Toast.LENGTH_LONG).show()

            else -> {
                Toast.makeText(this, "please wait, this will take a while", Toast.LENGTH_LONG).show()

                val auth: FirebaseAuth = FirebaseAuth.getInstance()

                auth.signInWithEmailAndPassword(email, password).addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        val intent = Intent(this@MainActivity, FinalActivity::class.java)
                        startActivity(intent)
                        finish()
                    }else{
                        Toast.makeText(this, "credentials are incorrect", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }



    }

    override fun onStart() {
        super.onStart()

        if(FirebaseAuth.getInstance().currentUser != null) {
            val intent = Intent(this@MainActivity, FinalActivity::class.java)
            startActivity(intent)
            finish()
        }

    }
}
