package com.example.myapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ListView
import androidx.appcompat.app.AlertDialog
import kotlinx.android.synthetic.main.activity_final.*

class FinalActivity : AppCompatActivity() {
    private var todoList: ListView? = null
    private var addButton: ImageButton? = null
    private var todoData: MutableList<String>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_final)

        init()
        settings_btn.setOnClickListener {
            val intent = Intent(this@FinalActivity, SettingsActivity::class.java)
            startActivity(intent)

        }
    }
    private fun init() {
        todoList = findViewById(R.id.todoList)
        addButton = findViewById(R.id.addButton)
        todoData = ArrayList<String>()

        addButton!!.setOnClickListener { addData() }
    }


    private fun addData() {
        val alert = AlertDialog.Builder(this)
        val edittext = EditText(this)
        alert.setTitle("Add item")

        alert.setView(edittext)
        alert.setPositiveButton("Add") {_, _ ->
            val value = edittext.text.toString()
            todoData!!.add(value)
            setToDoListAdapter(todoData)

        }

        alert.setNegativeButton("Cancel") {_, _ ->
        }

        alert.show()
    }


    private fun setToDoListAdapter(todoData: List<String>?) {
        val adapter = ArrayAdapter<String>(this, android.R.layout.simple_list_item_1)
        adapter.addAll(todoData!!.toMutableList())
        todoList!!.adapter = adapter
    }
}
