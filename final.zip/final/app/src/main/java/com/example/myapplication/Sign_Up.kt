package com.example.myapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.TextUtils
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import kotlinx.android.synthetic.main.activity_sign__up.*

class Sign_Up : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sign__up)

        signin_link_btn.setOnClickListener {
            startActivity(Intent(this@Sign_Up, MainActivity::class.java))
        }

        signup_btn.setOnClickListener {
            addAccount()
        }
    }

    private fun addAccount() {
        val fullName = fullname_signup.text.toString()
        val userName = username_signup.text.toString()
        val email = email_signup.text.toString()
        val password = password_signup.text.toString()

        when {
            TextUtils.isEmpty(fullName) -> Toast.makeText(this, "enter full name", Toast.LENGTH_LONG).show()
            TextUtils.isEmpty(userName) -> Toast.makeText(this, "enter username", Toast.LENGTH_LONG).show()
            TextUtils.isEmpty(email) -> Toast.makeText(this, "enter email", Toast.LENGTH_LONG).show()
            TextUtils.isEmpty(password) -> Toast.makeText(this, "enter password", Toast.LENGTH_LONG).show()

            else -> {
                Toast.makeText(this, "please wait, we are taking your credentials", Toast.LENGTH_LONG).show()

                val auth: FirebaseAuth = FirebaseAuth.getInstance()

                auth.createUserWithEmailAndPassword(email, password)
                    .addOnCompleteListener {task ->
                        if (task.isSuccessful)
                        {
                            userInfo(fullName, userName, email)

                        }
                        else {
                            Toast.makeText(this, "error while registering", Toast.LENGTH_LONG).show()
                        }
                    }
            }
        }

    }

    private fun userInfo(fullName: String, userName: String, email: String) {
        val userID = FirebaseAuth.getInstance().currentUser!!.uid
        val ref: DatabaseReference = FirebaseDatabase.getInstance().getReference("Users")

        val dict = HashMap<String, Any>()
        dict ["fullName"] = fullName
        dict ["userName"] = userName
        dict ["email"] = email

        ref.child(userID).setValue(dict)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    Toast.makeText(this, "your credentials has been stored on database! ", Toast.LENGTH_LONG).show()

                    val intent = Intent(this@Sign_Up, FinalActivity::class.java)
                    startActivity(intent)
                    finish()
                }
            }
    }
}
